package citationmachinetester;

import java.util.HashMap;

public class CitationMachine {
    String title, authorFirst, authorLast;
    String publishDay, publishMonth, publishYear;
    String accessDay, accessMonth, accessYear;
    String citation, citationType;
    
    public CitationMachine ( HashMap c ) {
        this.citationType = (String)c.get("citationType");
        
        this.title = (String)c.get("title");
        if ( this.title == null || this.title.equals("Title") )
            this.title = "";
        else
            this.title = "'" + this.title + ".' ";
        
        this.authorFirst = (String)c.get("authorFirst"); 
        if ( this.authorFirst == null || this.authorFirst.equals("FirstName") )
            this.authorFirst = "";
        else
            this.authorFirst = this.authorFirst + ". ";
        
        this.authorLast = (String)c.get("authorLast"); ;
        if ( this.authorLast == null || this.authorLast.equals("LastName") )
            this.authorLast = "";
        else
            this.authorLast = this.authorLast + ", ";
        
        this.accessDay = (String)c.get("accDay");
        this.accessMonth = (String)c.get("accMonth");
        this.accessYear = (String)c.get("accYear");
        
        if ( this.accessMonth == null || this.accessMonth.equals("Month") 
                || this.accessYear == null || this.accessYear.equals("Year") ) {
            this.accessDay = "";
            this.accessMonth = "";
            this.accessYear = "";
        } else if ( this.accessDay == null || this.accessDay.equals("Day")) {
            this.accessDay = "";
            this.accessMonth = this.accessMonth + " ";
            this.accessYear = this.accessYear + ". ";
        } else {
            this.accessDay = this.accessDay + " ";
            this.accessMonth = this.accessMonth + " ";
            this.accessYear = this.accessYear + ". ";
        }

        this.publishDay = (String)c.get("pubDay");
        this.publishMonth = (String)c.get("pubMonth");         
        this.publishYear = (String)c.get("pubYear");
        
        if ( this.publishYear == null || this.publishYear.equals("Year") ) {
            this.publishDay = "";
            this.publishMonth = "";
            this.publishYear = "n.d. ";
        } else if ( this.publishMonth == null || this.publishMonth.equals("Month") ) {
            this.publishDay = "";
            this.publishMonth = "";
            this.publishYear = this.publishYear + ". ";
        } else if ( this.publishDay == null || this.publishDay.equals("Day") ) {
            this.publishDay = this.publishDay + " ";
            this.publishMonth = this.publishMonth + " ";
            this.publishYear = this.publishYear + ". ";
        }

    }
     
    
    public void createBibliography() {
        
    }
    
}
