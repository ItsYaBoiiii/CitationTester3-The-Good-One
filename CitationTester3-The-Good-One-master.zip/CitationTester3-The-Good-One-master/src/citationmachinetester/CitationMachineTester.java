package citationmachinetester;

public class CitationMachineTester {

    public static void main(String[] args) {
        CitationGUI g = new CitationGUI();
        g.setVisible(true);
    }
}
